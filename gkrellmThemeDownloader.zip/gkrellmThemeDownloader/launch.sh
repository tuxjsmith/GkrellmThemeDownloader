# if you use the .desktop file on your Linux desktop then
# remove # from the front of: cd /pathTo... 
# and change: cd /pathTo... to the full path of
# this directory: javafxgkrellmthemedownloader
# then: save

# need help ? please contact me at:
# Google+ community: https://plus.google.com/u/0/communities/103132436474934296147
# IRC: irc.freenode.net #logFarm
# https://webchat.freenode.net

#cd /pathTo/javafxgkrellmthemedownloader
java -jar ./javaFXGkrellmThemeDownloader.jar
